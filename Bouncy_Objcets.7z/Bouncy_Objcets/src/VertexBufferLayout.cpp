#include "VertexBufferLayout.h"
VertexBufferLayout::VertexBufferLayout() {

}